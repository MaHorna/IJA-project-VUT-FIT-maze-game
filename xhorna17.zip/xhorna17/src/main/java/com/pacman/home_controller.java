/**
 * @author Matej Horňanský
 *
 * Class
 */
package com.pacman;

/**
 * Home controller
 */
public class home_controller {

}
